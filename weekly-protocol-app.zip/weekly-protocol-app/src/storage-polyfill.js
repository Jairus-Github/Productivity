// Polyfills the window.storage API that Claude artifacts provide, backed by the
// browser's localStorage, so the app works unmodified once it's deployed on its own.
function keyFor(key, shared) {
  return `${shared ? "shared" : "personal"}:${key}`;
}

window.storage = {
  async get(key, shared = false) {
    const raw = localStorage.getItem(keyFor(key, shared));
    if (raw === null) throw new Error(`Key not found: ${key}`);
    return { key, value: raw, shared };
  },
  async set(key, value, shared = false) {
    localStorage.setItem(keyFor(key, shared), value);
    return { key, value, shared };
  },
  async delete(key, shared = false) {
    localStorage.removeItem(keyFor(key, shared));
    return { key, deleted: true, shared };
  },
  async list(prefix = "", shared = false) {
    const fullPrefix = keyFor(prefix, shared);
    const scopePrefix = shared ? "shared:" : "personal:";
    const keys = Object.keys(localStorage)
      .filter((k) => k.startsWith(fullPrefix))
      .map((k) => k.slice(scopePrefix.length));
    return { keys, prefix, shared };
  },
};
